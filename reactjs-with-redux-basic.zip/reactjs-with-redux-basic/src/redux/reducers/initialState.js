export default {
    changeSort:{},
    items: [
        {
          "id": 1,
          "name": "deneme",
          "link": "link vs ",
          "upVote": 0,
          "downVote": 0,
          "lastVoteUpdated":new Date()
        }
    ]
    
}